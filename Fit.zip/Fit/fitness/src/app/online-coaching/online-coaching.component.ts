import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-coaching',
  templateUrl: './online-coaching.component.html',
  styleUrls: ['./online-coaching.component.css']
})
export class OnlineCoachingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
