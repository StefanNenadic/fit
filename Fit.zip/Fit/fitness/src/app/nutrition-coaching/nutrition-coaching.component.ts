import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nutrition-coaching',
  templateUrl: './nutrition-coaching.component.html',
  styleUrls: ['./nutrition-coaching.component.css']
})
export class NutritionCoachingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
