import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NutritionCoachingComponent } from './nutrition-coaching.component';

describe('NutritionCoachingComponent', () => {
  let component: NutritionCoachingComponent;
  let fixture: ComponentFixture<NutritionCoachingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NutritionCoachingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NutritionCoachingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
